Vincent Ou
CSC 214
11/18/18
HW 8

 “I affirm that I have not given or received any unauthorized help on this
assignment, and that this work is my own.”