//
//  Button.swift
//  Memorizer
//
//  Created by Vincent Ou on 10/3/18.
//  Copyright © 2018 Vincent Ou. All rights reserved.
//

import Foundation
import UIKit

class Button: UIButton {
    
    var index = 0
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
    }
    
}
