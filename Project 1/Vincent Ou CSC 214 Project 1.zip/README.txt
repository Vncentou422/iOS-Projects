Vincent Ou
CSC 214
Project 1
10/3/2018

“I affirm that I have not given or received any unauthorized help on this assignment, and that this work is my own.”

I have originally tried to make the buttons flash in regards to the sequence but I could not make the buttons flash at intervals because for some reason I could not delay anything while it It was in a for loop/while loop so all the buttons of the sequence would flash at the same time. Therefore I adjusted and made the sequence appear as a String for the user to memorize.

The delay and flash function are from my research regarding animations and time delays given that we did not learn these aspects yet in class. These functions were purely for aesthetic aspects and thus the app will still function without these aspects added to them. 